#ifndef PROCESS_H
#define PROCESS_H

void process(char *);

#endif
