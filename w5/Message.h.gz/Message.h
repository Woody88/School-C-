// Woodson Delhia
// Workshop 5 
// BTP305

#ifndef MESSAGE_H
#define MESSAGE_H

#include<iostream>

namespace w5 {
class Message{
	std::string username, tweet, reply;
	
	public:
	Message();
	Message(std::ifstream& in, char c);
	bool empty() const;
	void display(std::ostream&) const;
};
}

#endif