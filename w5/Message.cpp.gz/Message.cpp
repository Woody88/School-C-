#include<iostream>
#include<fstream>
#include<string>
#include "Message.h" 

using namespace w5;

Message::Message(){}

Message::Message(std::ifstream& in, char c){

	bool userSet = false;
	bool replyFlag = false;
	bool tweetFlag = false;

	if ( in.good()) {
		// std::string str;
		// getline(in, str, c);
		std::string str;
		getline(in, str, c);

		 for ( std::string::iterator it=str.begin(); it!=str.end(); ++it){
		 	
		 	if (*it != ' ' && !userSet && !tweetFlag){
		 		username += *it;
		 	}
		 	else if ( *it == ' ' && *(it+1) == '@'){
		 		userSet = true;
		 		replyFlag = true;
		 		it++;
		 	}
		 	else if ( *it == ' ' && *(it+1) != '@'){
		 		tweetFlag = true;
		 		tweet += *it;
		 	}
		 	else if ( replyFlag && !tweetFlag ){
		 		reply += *it;
		 	}
		 	else{
		 		tweet += *it;
		 	}

		 }

		 std::cout << tweet << std::endl;
    		
    		
		
	}
}

bool Message::empty() const{
	return  (username.empty() && tweet.empty() && reply.empty());
}
void Message::display(std::ostream& os) const{
	
	if (!tweet.empty()){
		os << "Message" << std::endl;
		os << "  User : " << username << std::endl;
		if (!reply.empty())
			os << "  Reply : " << reply << std::endl;
		os << "  Tweet : " << tweet << std::endl;
	}
}	