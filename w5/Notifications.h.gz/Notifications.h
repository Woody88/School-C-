// Woodson Delhia
// Workshop 5 
// BTP305

#ifndef NOTIFICATIONS_H
#define NOTIFICATIONS_H


#include<iostream>
#include "Message.h"  

namespace w5{
	class Notifications{

		private: 
		Message messages[10];
		int msgIndex;

		public:
		
		Notifications();
		Notifications(const Notifications&);
		Notifications& operator=(const Notifications&);
		Notifications(Notifications&&);
		Notifications&& operator=(Notifications&&); 
		~Notifications();
		void operator+=(const Message& msg);
		void display(std::ostream& os) const; 

	};
}

#endif