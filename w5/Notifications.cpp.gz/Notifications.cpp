#include<iostream>
#include "Notifications.h"

using namespace w5;

Notifications::Notifications() {
	msgIndex = 0;
}

Notifications::Notifications(const Notifications& notif){
	*this = notif;
}

Notifications::Notifications(Notifications&& notif){
	*this = notif; 
}

Notifications::~Notifications(){
	msgIndex = 0;
}

Notifications& Notifications::operator=(const Notifications& notif){

	if (this != &notif)
		*this = notif;

	return *this;
}	


Notifications&& Notifications::operator=(Notifications&& notif){
	if (this != &notif)
		*this = notif;

	return std::move(*this);
}
void Notifications::operator+=(const Message& msg){
	if (msgIndex < 10){
		messages[msgIndex] = msg;
		msgIndex++;
	}
}

void Notifications::display(std::ostream& os) const{
	for(int i = 0; i < msgIndex; i++)
		messages[i].display(os);
}